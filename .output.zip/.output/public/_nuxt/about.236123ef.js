import{a as e,b as o,o as t}from"./entry.f6e58032.js";const c={},a={id:"about"};function n(r,s){return t(),o("div",a,"page About")}const d=e(c,[["render",n]]);export{d as default};
